# Screenshaken mod

A standalone mod to backport the screen shake modifier functionality from 1.5.78 to 1.3.1.5 and 1.4.3.2

## Credits

The code is based on the screenshake modifier patch from [peekagrub/AssemblyPatches](https://github.com/peekagrub/AssemblyPatches/).
All credits to the original authors (peekagrub and TheMulhima).
